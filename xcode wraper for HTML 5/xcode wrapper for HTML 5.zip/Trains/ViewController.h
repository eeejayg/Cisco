//
//  ViewController.h
//  Trains
//
//  Created by Robert Eickmann on 5/10/14.
//  Copyright (c) 2014 devnull. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIWebViewDelegate>

@property (nonatomic, retain) IBOutlet UIWebView *webView;

@end
