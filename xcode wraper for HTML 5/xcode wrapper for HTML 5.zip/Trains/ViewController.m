//
//  ViewController.m
//  Trains
//
//  Created by Robert Eickmann on 5/10/14.
//  Copyright (c) 2014 devnull. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize webView;

NSString *currentURL;


//To Turn on the Status bar header comment out this block.

- (BOOL)prefersStatusBarHidden {
    return YES;
}

// End of comment Block.

//Also set this variable to = 20;
int showStatusBarHeight = 0;

//End of Status Bar Changes

//http://www.touch-code-magazine.com/web-color-to-uicolor-convertor/ 
//[self.view setbackgroundColor:[UIColor blueColor]];


- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    NSLog(@"%@", error);
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    NSURL *requestURL = [ request URL ];
    
    if ( [[requestURL scheme] isEqualToString: @"http"] || [[requestURL scheme] isEqualToString: @"https"] ) {
        //[[ UIApplication sharedApplication ] openURL: [NSURL URLWithString: [[requestURL absoluteString] stringByReplacingOccurrencesOfString:@"ext://" withString:@"http://"] ]];
        [[ UIApplication sharedApplication ] openURL: [NSURL URLWithString: [requestURL absoluteString] ]];
        return NO;
    } else  {
        return YES;
    }
}

-(void)viewDidAppear:(BOOL)animated {
    webView.delegate = self;
    
    

    NSString* filePath = [[NSBundle mainBundle] pathForResource:@"index"
                                                         ofType:@"html"
                                                    inDirectory:@"website"];
    
    NSURL* fileURL = [NSURL fileURLWithPath:filePath];
    NSURLRequest* request = [NSURLRequest requestWithURL:fileURL];
    [webView loadRequest:request];
    
    
    
}




- (void)viewDidLoad
{
    [super viewDidLoad];
    webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, showStatusBarHeight, self.view.bounds.size.height, self.view.bounds.size.width)];
    webView.scrollView.scrollEnabled = NO;
    webView.scrollView.bounces = NO;
    
    [self.view addSubview:webView];


    //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(resetWebView) name:UIApplicationWillResignActiveNotification  object:nil];
    

    
	// Do any additional setup after loading the view, typically from a nib.
}

-(void)monkeySelector {
    NSLog(@"Monkey");
}

-(void)viewWillDisappear:(BOOL)animated {
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIApplicationDidBecomeActiveNotification object:nil];
    
}


-(void)resetWebView {
    NSLog(@"resetWebView");
    [webView reload];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
